import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import ProductosPage from "./pages/ProductosPage";
import ClientesPage from "./pages/ClientesPage";
import FacturacionPage from "./pages/FacturacionPage";
import Footer from "./components/Footer";

function App() {
  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-gray-50 text-gray-800">
        {/* 🔹 NAVBAR */}
        <nav className="bg-blue-600 text-white p-4 shadow-md flex justify-between items-center">
          <h1 className="text-xl font-semibold">Sistema de Pañol</h1>
          <div className="space-x-4">
            <Link to="/" className="hover:underline">Productos</Link>
            <Link to="/clientes" className="hover:underline">Clientes</Link>
            <Link to="/facturacion" className="hover:underline">Facturación</Link>
          </div>
        </nav>

        {/* 🔹 CONTENIDO PRINCIPAL */}
        <main className="flex-1 p-6">
          <Routes>
            <Route path="/" element={<ProductosPage />} />
            <Route path="/clientes" element={<ClientesPage />} />
            <Route path="/facturacion" element={<FacturacionPage />} />
          </Routes>
        </main>

        {/* 🔹 FOOTER */}
        <Footer />
      </div>
    </Router>
  );
}

export default App;