import { useState, useEffect } from "react";
import ProductForm from "../components/ProductForm";
import ProductCard from "../components/ProductCard";

function ProductosPage() {
  const [productos, setProductos] = useState([]);
  const [busqueda, setBusqueda] = useState("");
  const [productoEdit, setProductoEdit] = useState(null);
  const [mostrarForm, setMostrarForm] = useState(false);

  // Cargar productos desde localStorage
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem("productos")) || [];
    setProductos(data);
  }, []);

  // Guardar productos en localStorage
  useEffect(() => {
    localStorage.setItem("productos", JSON.stringify(productos));
  }, [productos]);

  // Agregar o editar producto
  const handleSave = (producto) => {
    if (productoEdit) {
      setProductos(productos.map((p) => (p.id === producto.id ? producto : p)));
    } else {
      producto.id = Date.now();
      setProductos([...productos, producto]);
    }
    setMostrarForm(false);
    setProductoEdit(null);
  };

  // Eliminar producto
  const handleDelete = (id) => {
    if (confirm("¿Seguro que quieres eliminar este producto?")) {
      setProductos(productos.filter((p) => p.id !== id));
    }
  };

  // Filtrar productos
  const productosFiltrados = productos.filter((p) =>
    p.nombre.toLowerCase().includes(busqueda.toLowerCase())
  );

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-blue-700">Gestión de Productos</h2>
        <button
          onClick={() => {
            setProductoEdit(null);
            setMostrarForm(true);
          }}
          className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
        >
           Nuevo Producto
        </button>
      </div>

      {/* Buscador */}
      <input
        type="text"
        placeholder="Buscar producto..."
        value={busqueda}
        onChange={(e) => setBusqueda(e.target.value)}
        className="border p-2 rounded w-full mb-4"
      />

      {/* Lista de productos */}
      {productosFiltrados.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {productosFiltrados.map((producto) => (
            <ProductCard
              key={producto.id}
              producto={producto}
              onEdit={() => {
                setProductoEdit(producto);
                setMostrarForm(true);
              }}
              onDelete={() => handleDelete(producto.id)}
            />
          ))}
        </div>
      ) : (
        <p className="text-gray-500">No hay productos registrados.</p>
      )}

      {/* Formulario modal */}
      {mostrarForm && (
        <ProductForm
          productoEdit={productoEdit}
          onSave={handleSave}
          onClose={() => setMostrarForm(false)}
        />
      )}
    </div>
  );
}

export default ProductosPage;