function Footer() {
  return (
    <footer className="bg-blue-600 text-white text-center py-3 mt-auto">
      <p>Sistema de Pañol | Desarrollado por Dannae Rodríguez</p>
    </footer>
  );
}

export default Footer;