import { useState, useEffect } from "react";

function ProductForm({ productoEdit, onSave, onClose }) {
  const [producto, setProducto] = useState({
    nombre: "",
    categoria: "",
    precio: "",
    stock: "",
  });

  // Cargar datos al editar
  useEffect(() => {
    if (productoEdit) setProducto(productoEdit);
  }, [productoEdit]);

  const handleChange = (e) => {
    setProducto({ ...producto, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validaciones básicas
    if (!producto.nombre || !producto.precio || !producto.stock) {
      alert("Por favor completa todos los campos obligatorios.");
      return;
    }
    if (producto.precio <= 0 || producto.stock < 0) {
      alert("El precio o el stock no pueden ser negativos.");
      return;
    }
    onSave(producto);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-40 flex justify-center items-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-lg w-96">
        <h3 className="text-lg font-bold mb-4 text-blue-700">
          {productoEdit ? "Editar Producto" : "Nuevo Producto"}
        </h3>

        <form onSubmit={handleSubmit}>
          <label className="block mb-2">Nombre:</label>
          <input
            name="nombre"
            value={producto.nombre}
            onChange={handleChange}
            className="border p-2 w-full mb-3 rounded"
            required
          />

          <label className="block mb-2">Categoría:</label>
          <input
            name="categoria"
            value={producto.categoria}
            onChange={handleChange}
            className="border p-2 w-full mb-3 rounded"
          />

          <label className="block mb-2">Precio ($):</label>
          <input
            name="precio"
            type="number"
            value={producto.precio}
            onChange={handleChange}
            className="border p-2 w-full mb-3 rounded"
            required
          />

          <label className="block mb-2">Stock:</label>
          <input
            name="stock"
            type="number"
            value={producto.stock}
            onChange={handleChange}
            className="border p-2 w-full mb-4 rounded"
            required
          />

          <div className="flex justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="bg-gray-400 text-white px-4 py-2 rounded hover:bg-gray-500"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Guardar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ProductForm;