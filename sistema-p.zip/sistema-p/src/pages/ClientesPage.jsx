function ClientesPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-blue-700 mb-4">Gestión de Clientes</h2>
      <p className="text-gray-600">Sección en construcción... próximamente podrás registrar y administrar tus clientes.</p>
    </div>
  );
}

export default ClientesPage;