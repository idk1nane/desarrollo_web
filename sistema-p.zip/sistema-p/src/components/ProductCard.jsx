function ProductCard({ producto, onEdit, onDelete }) {
  return (
    <div className="bg-white rounded-lg shadow-md p-4 border">
      <h4 className="text-lg font-semibold text-blue-600">{producto.nombre}</h4>
      <p>Categoría: {producto.categoria || "N/A"}</p>
      <p>Precio: ${producto.precio}</p>
      <p>Stock: {producto.stock}</p>

      <div className="flex justify-end gap-2 mt-3">
        <button
          onClick={onEdit}
          className="bg-yellow-400 px-3 py-1 rounded hover:bg-yellow-500"
        >
        Editar
        </button>
        <button
          onClick={onDelete}
          className="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600"
        >
        Eliminar
        </button>
      </div>
    </div>
  );
}

export default ProductCard;