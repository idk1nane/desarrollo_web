function FacturacionPage() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-blue-700 mb-4">Módulo de Facturación</h2>
      <p className="text-gray-600">Aquí se mostrarán los reportes de facturación y los movimientos de ventas.</p>
    </div>
  );
}

export default FacturacionPage;