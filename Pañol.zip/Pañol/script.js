// Inventario inicial
const inventario = [
  { id: 1, nombre: "Martillo", categoria: "Herramienta", stock: 5 },
  { id: 2, nombre: "Multímetro", categoria: "Equipo", stock: 3 },
  { id: 3, nombre: "Cables", categoria: "Material", stock: 20 }
];

// Estado de sesión
let usuarioActivo = null;

//login
document.getElementById("loginForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const username = document.getElementById("username").value;
  const role = document.getElementById("role").value;

  usuarioActivo = { username, role };
  localStorage.setItem("usuarioActivo", JSON.stringify(usuarioActivo));

  document.getElementById("loginSection").classList.add("hidden");
  document.getElementById("mainSection").classList.remove("hidden");
  
  renderInventario();
  renderSolicitudes();
  renderUsuarios();
  renderReportes();

  // Mostrar/Ocultar gestión de usuarios y reportes según rol
  const usuariosBtn = document.querySelector("nav button[onclick=\"showSection('usuarios')\"]");
  const reportesBtn = document.querySelector("nav button[onclick=\"showSection('reportes')\"]");

  if (role === "Alumno" || role === "Docente") {
    usuariosBtn.style.display = "none";
    reportesBtn.style.display = "none";
  } else {
    usuariosBtn.style.display = "inline-block";
    reportesBtn.style.display = "inline-block";
  }
});

// Logout
function logout() {
  localStorage.removeItem("usuarioActivo");
  usuarioActivo = null;
  document.getElementById("mainSection").classList.add("hidden");
  document.getElementById("loginSection").classList.remove("hidden");
}

// navegacion
function showSection(sectionId) {
  document.querySelectorAll(".content").forEach(c => c.classList.add("hidden"));
  document.getElementById(sectionId).classList.remove("hidden");
}

// inventario
function renderInventario() {
  const tbody = document.getElementById("inventoryTable");
  tbody.innerHTML = "";

  inventario.forEach(item => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${item.id}</td>
      <td>${item.nombre}</td>
      <td>${item.categoria}</td>
      <td>${item.stock}</td>
      <td><button onclick="solicitar(${item.id})">Solicitar</button></td>
    `;
    tbody.appendChild(tr);
  });
}

// solicitudes
function solicitar(id) {
  if (!usuarioActivo) return alert("Debes iniciar sesión");

  let solicitudes = JSON.parse(localStorage.getItem("solicitudes")) || [];
  const item = inventario.find(i => i.id === id);

  if (item.stock > 0) {
    solicitudes.push({ usuario: usuarioActivo.username, producto: item.nombre, fecha: new Date().toLocaleString() });
    localStorage.setItem("solicitudes", JSON.stringify(solicitudes));

    item.stock--;
    renderInventario();
    renderSolicitudes();
    renderReportes();
    alert("Solicitud registrada!");
  } else {
    alert("Stock no disponible");
  }
}

function renderSolicitudes() {
  let solicitudes = JSON.parse(localStorage.getItem("solicitudes")) || [];
  const lista = document.getElementById("solicitudesList");
  lista.innerHTML = "";

  solicitudes
    .filter(s => s.usuario === usuarioActivo?.username)
    .forEach(s => {
      const li = document.createElement("li");
      li.textContent = `${s.producto} - ${s.fecha}`;
      lista.appendChild(li);
    });
}

// usuarios u.u
document.getElementById("userForm")?.addEventListener("submit", function(e) {
  e.preventDefault();

  if (usuarioActivo.role !== "Pañolero" && usuarioActivo.role !== "Jefe" && usuarioActivo.role !== "Coordinador") {
    alert("No tienes permisos para registrar usuarios.");
    return;
  }

  const username = document.getElementById("newUsername").value;
  const email = document.getElementById("newEmail").value;
  const role = document.getElementById("newRole").value;

  let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  usuarios.push({ username, email, role });
  localStorage.setItem("usuarios", JSON.stringify(usuarios));

  renderUsuarios();
  renderReportes();
  document.getElementById("userForm").reset();
  alert("Usuario registrado correctamente ✅");
});

// mostrar usuarios
function renderUsuarios() {
  const lista = document.getElementById("userList");
  if (!lista) return;

  lista.innerHTML = "";
  let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];
  usuarios.forEach(u => {
    const li = document.createElement("li");
    li.textContent = `${u.username} (${u.role}) - ${u.email}`;
    lista.appendChild(li);
  });
}

//reportes
function renderReportes() {
  const totalSolicitudes = (JSON.parse(localStorage.getItem("solicitudes")) || []).length;
  const totalUsuarios = (JSON.parse(localStorage.getItem("usuarios")) || []).length;

  document.getElementById("totalSolicitudes").textContent = totalSolicitudes;
  document.getElementById("totalUsuarios").textContent = totalUsuarios;
}
